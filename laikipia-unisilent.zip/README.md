# Laikipia Unisilent 🔞

Anonymous confession app built with Next.js + Supabase + Tailwind CSS.

## Setup

1. Clone the repo
2. Add `.env.local` with:
   ```
   NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_key
   ```

3. Run the app:
   ```
   npm install
   npm run dev
   ```

4. Deploy to Vercel
